﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MakeingTestFromGroundUp
{
    public class Kyle : People
    {
        public Kyle()
        {
            
        }


    }
}
