﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MakeingTestFromGroundUp
{
    public abstract class People
    {

        public int Power { get; set; }

        public string Name { get; set; }

        public int Health { get; set; }

        public string AttackType { set; get; }

        public People()
        {

        }


        
    }
}
