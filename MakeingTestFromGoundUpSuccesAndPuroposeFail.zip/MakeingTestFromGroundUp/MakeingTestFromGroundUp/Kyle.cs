﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MakeingTestFromGroundUp
{
    public class Kyle : People
    {
        public Kyle()
        {
            Name = "Kyle";

            Power = 50;

            Health = 6000;

            AttackType = "Bubbles";
        }


    }
}
