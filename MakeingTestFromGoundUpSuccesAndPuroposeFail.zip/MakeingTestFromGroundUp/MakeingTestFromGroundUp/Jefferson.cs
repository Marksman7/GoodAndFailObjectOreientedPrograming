﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MakeingTestFromGroundUp
{
    class Jefferson : People
    {
        public Jefferson()
        {
            Name = "Jeffereson";

            Power = 10;

            Health = 10000;

            AttackType = "Danger Poke";
        }


    }
}