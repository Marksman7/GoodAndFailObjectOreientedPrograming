﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MakeingTestFromGroundUp
{
    class NotTony : People
    {
        public NotTony()
        {
            Name = "Tony";

            Power = 40;

            Health = 8000;

            AttackType = "Axe Throw";
        }


    }
}