﻿using System;

namespace MakeingTestFromGroundUp
{
    class Program
    {
        static void Main(string[] args)
        {
            CreatingThreeWayGame Ok = new CreatingThreeWayGame();
            Ok.Play();
        }
    }
}
